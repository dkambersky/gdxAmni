#!/bin/sh
export LANG=C
export DEVELPACKAGE=1
export LINK_STATIC=1
export JAVA_HOME=C:/Programme/Java/jdk1.5.0_21
#export LIBCURL_PATH=../curl-7.29.0-devel-mingw32
export LIBCURL_PATH=../curl-7.29.0-winssl-sspi-spnego-zlib-devel-w32
export ZLIB_PATH=../curl-7.29.0-devel-mingw32/lib
export OPENSSL_PATH=../curl-7.29.0-devel-mingw32
export LIBSSH2_PATH=../curl-7.29.0-devel-mingw32
export LDAP_SDK=../curl-7.29.0-devel-mingw32

